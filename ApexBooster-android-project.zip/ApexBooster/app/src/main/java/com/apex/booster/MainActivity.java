package com.apex.booster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_VOICE = 42;
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);

        // Serve assets over https:// so the page is a "secure context"
        // (required by the Battery and deviceMemory APIs).
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String js = "window.onVoiceResult && window.onVoiceResult(" + JSONObject.quote(r.get(0)) + ")";
                web.evaluateJavascript(js, null);
            }
        }
    }

    /** Functions the web page can call as window.Android.* */
    private class Bridge {

        /** Launchable apps as JSON: [{name, pkg, isGame}] */
        @JavascriptInterface
        public String getApps() {
            try {
                PackageManager pm = getPackageManager();
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
                JSONArray arr = new JSONArray();
                Set<String> seen = new HashSet<>();
                for (ResolveInfo ri : list) {
                    ApplicationInfo ai = ri.activityInfo.applicationInfo;
                    String pkg = ai.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                    boolean isGame = (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                    if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) {
                        isGame = true;
                    }
                    JSONObject o = new JSONObject();
                    o.put("name", ri.loadLabel(pm).toString());
                    o.put("pkg", pkg);
                    o.put("isGame", isGame);
                    arr.put(o);
                }
                return arr.toString();
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface
        public boolean launch(String pkg) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return false;
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String getSystemInfo() {
            try {
                JSONObject o = new JSONObject();

                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                o.put("ramTotal", mi.totalMem);
                o.put("ramAvail", mi.availMem);

                StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
                o.put("diskTotal", fs.getTotalBytes());
                o.put("diskAvail", fs.getAvailableBytes());

                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                int temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) : -1;
                o.put("battTemp", temp < 0 ? JSONObject.NULL : temp / 10.0);
                o.put("battVolt", b != null ? b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) : 0);
                int lvl = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
                int scale = b != null ? b.getIntExtra(BatteryManager.EXTRA_SCALE, 100) : 100;
                o.put("battLevel", lvl < 0 ? JSONObject.NULL : Math.round(lvl * 100f / scale));
                int plugged = b != null ? b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) : 0;
                String pl = "Tidak";
                if (plugged == BatteryManager.BATTERY_PLUGGED_AC) pl = "Charger (AC)";
                else if (plugged == BatteryManager.BATTERY_PLUGGED_USB) pl = "USB";
                else if (plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS) pl = "Nirkabel";
                o.put("plugged", pl);

                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                o.put("powerSave", pm.isPowerSaveMode());
                String thermal = "N/A";
                if (Build.VERSION.SDK_INT >= 29) {
                    String[] names = {"Normal", "Ringan", "Sedang", "Berat", "Kritis", "Darurat", "Mati"};
                    int t = pm.getCurrentThermalStatus();
                    thermal = (t >= 0 && t < names.length) ? names[t] : "N/A";
                }
                o.put("thermal", thermal);

                o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
                o.put("android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
                return o.toString();
            } catch (Exception e) {
                return "null";
            }
        }

        /** Opens the system speech recognizer (prefers offline language pack). */
        @JavascriptInterface
        public boolean startVoice() {
            final Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan perintah...");
            if (i.resolveActivity(getPackageManager()) == null) return false;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { startActivityForResult(i, REQ_VOICE); } catch (Exception ignored) { }
                }
            });
            return true;
        }

        @JavascriptInterface
        public boolean openSettings(String key) {
            String action;
            switch (key) {
                case "wifi": action = Settings.ACTION_WIFI_SETTINGS; break;
                case "battery": action = Settings.ACTION_BATTERY_SAVER_SETTINGS; break;
                case "display": action = Settings.ACTION_DISPLAY_SETTINGS; break;
                case "storage": action = Settings.ACTION_INTERNAL_STORAGE_SETTINGS; break;
                case "apps": action = Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS; break;
                case "developer": action = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS; break;
                case "bluetooth": action = Settings.ACTION_BLUETOOTH_SETTINGS; break;
                case "sound": action = Settings.ACTION_SOUND_SETTINGS; break;
                case "airplane": action = Settings.ACTION_AIRPLANE_MODE_SETTINGS; break;
                case "batteryopt": action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS; break;
                default: return false;
            }
            try {
                Intent i = new Intent(action);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
