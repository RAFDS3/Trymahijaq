# Apex Booster (Android)

Proyek Android (WebView) yang membungkus `app/src/main/assets/index.html`.

## Cara membuat APK
**A. Android Studio:** File > Open > pilih folder ini > tunggu sync > Build > Build APK(s).
File: app/build/outputs/apk/debug/app-debug.apk

**B. Tanpa Android Studio:** unggah folder ini ke repo GitHub, buka tab Actions > Build APK > Run workflow,
lalu unduh artifact "apex-booster-apk".

Catatan: tampilan memakai Tailwind & Font Awesome dari CDN, jadi butuh internet saat aplikasi dibuka.
